(function(window, undefined) {
  var dictionary = {
    "36d2f015-abae-4f2f-a110-d6177531f989": "마이페이지_분석_내 활동",
    "1e108807-f230-401b-8185-7389f08d0b17": "About-사용방법",
    "488b1af8-8a20-47c9-97f4-131e41bfb5d4": "About-팀소개",
    "b3f2ea80-8082-45e1-a49c-1ad8694df270": "About-기획의도",
    "91845f6d-7bda-4bf0-a727-4f29ef06d63d": "마이페이지_타임라인",
    "b387c5f1-af65-4f53-b6e1-1d782b189f8d": "마이페이지_그룹관리_그룹조회",
    "51c748a2-a5a7-4092-a6bc-df0765e8599c": "마이페이지_그룹관리_그룹 생성",
    "81fe4d50-2e2c-44c5-9e73-71826b13916f": "메인페이지-결과화면",
    "daf796ec-fa9e-403f-a444-49e9fbec7a51": "마이페이지_그룹관리_내 그룹",
    "2855b801-1ae2-4cb9-93b5-b3745a6625e8": "카카오 로그인",
    "38c92bb4-55d7-4bdf-a8b2-9f4ecafb048c": "마이페이지_분석_그룹",
    "c36295aa-eb22-4ff8-b626-451d7c2861e3": "메인페이지-실행화면",
    "392d8119-a66b-4114-b7b1-a787537d5eb3": "마이페이지_그룹관리_그룹 찾기",
    "a9b9b05f-58d3-4f8b-b613-f4ece5dd27e8": "마이페이지_타임라인 상세",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "마이페이지_양식",
    "0634c820-e80a-4639-8d13-5e326c7185b0": "마이페이지_그룹관리_빈 그룹",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);