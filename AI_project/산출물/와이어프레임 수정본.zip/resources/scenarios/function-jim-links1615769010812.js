(function(window, undefined) {

  var jimLinks = {
    "36d2f015-abae-4f2f-a110-d6177531f989" : {
    },
    "81fe4d50-2e2c-44c5-9e73-71826b13916f" : {
      "Rectangle_9" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ]
    },
    "2855b801-1ae2-4cb9-93b5-b3745a6625e8" : {
      "Image_1" : [
        "c36295aa-eb22-4ff8-b626-451d7c2861e3"
      ]
    },
    "38c92bb4-55d7-4bdf-a8b2-9f4ecafb048c" : {
    },
    "c36295aa-eb22-4ff8-b626-451d7c2861e3" : {
      "Rectangle_5" : [
        "81fe4d50-2e2c-44c5-9e73-71826b13916f"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);