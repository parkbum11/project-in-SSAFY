var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1920" deviceHeight="1080">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1920" height="1080">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1615769010812.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1615769010812-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-c36295aa-eb22-4ff8-b626-451d7c2861e3" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="메인페이지-실행화면" width="1920" height="1080">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/c36295aa-eb22-4ff8-b626-451d7c2861e3-1615769010812.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/c36295aa-eb22-4ff8-b626-451d7c2861e3-1615769010812-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/c36295aa-eb22-4ff8-b626-451d7c2861e3-1615769010812-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Rectangle_3" class="pie rectangle manualfit firer commentable non-processed" customid="전체 배경"   datasizewidth="1920.0px" datasizeheight="1080.0px" datasizewidthpx="1919.9999999999998" datasizeheightpx="1080.0" dataX="0.0" dataY="0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="상단 바" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_1" class="pie rectangle manualfit firer commentable non-processed" customid="상단 바 배경"   datasizewidth="1920.0px" datasizeheight="120.0px" datasizewidthpx="1919.9999999999998" datasizeheightpx="120.0" dataX="0.0" dataY="0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="회원 아이콘" datasizewidth="60.0px" datasizeheight="60.0px" >\
          <div id="shapewrapper-s-Ellipse_1" customid="Ellipse_1" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="89.0px" datasizeheight="89.0px" datasizewidthpx="89.0" datasizeheightpx="89.0" dataX="1804.0" dataY="16.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Ellipse_1)">\
                              <ellipse id="s-Ellipse_1" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_1" cx="44.5" cy="44.5" rx="44.5" ry="44.5">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                              <ellipse cx="44.5" cy="44.5" rx="44.5" ry="44.5">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Ellipse_1" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Ellipse_1_0"></span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
\
          <div id="s-Image_35" class="pie image firer ie-background commentable non-processed" customid="Image_35"   datasizewidth="44.5px" datasizeheight="51.9px" dataX="1826.0" dataY="33.0"   alt="image" systemName="./images/58407403-57b3-4bb4-8cc6-663cee0f6629.svg" overlay="#999999">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 17 20" width="17px">\
              	    <!-- Generator: Sketch 52.1 (67048) - http://www.bohemiancoding.com/sketch -->\
              	    <title>user</title>\
              	    <desc>Created with Sketch.</desc>\
              	    <g fill="none" fill-rule="evenodd" id="s-Image_35-Page-1" stroke="none" stroke-width="1">\
              	        <g fill="#666666" id="s-Image_35-user">\
              	            <path d="M8.63492063,0 C5.80790159,0 3.50793651,2.29996508 3.50793651,5.12698413 C3.50793651,7.95400317 5.80790159,10.2539683 8.63492063,10.2539683 C11.4619397,10.2539683 13.7619048,7.95400317 13.7619048,5.12698413 C13.7619048,2.29996508 11.4619397,0 8.63492063,0" id="s-Image_35-Fill-1" style="fill:#999999 !important;" />\
              	            <path d="M9.63332578,11.4682653 L7.36665911,11.4682653 C5.40191244,11.4682653 3.55087689,12.2442836 2.15461022,13.65341 C0.765181333,15.0556274 -7.55555556e-06,16.9065514 -7.55555556e-06,18.8653527 C-7.55555556e-06,19.1764059 0.253708,19.4285827 0.566659111,19.4285827 L16.4333258,19.4285827 C16.7462769,19.4285827 16.9999924,19.1764059 16.9999924,18.8653527 C16.9999924,16.9065514 16.2348036,15.0556274 14.8453747,13.65341 C13.449108,12.2442836 11.5981102,11.4682653 9.63332578,11.4682653 Z" id="s-Image_35-Fill-3" style="fill:#999999 !important;" />\
              	        </g>\
              	    </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
\
        </div>\
\
\
        <div id="s-Group_6" class="group firer ie-background commentable non-processed" customid="로고" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Image_24" class="pie image firer ie-background commentable non-processed" customid="로고 이미지"   datasizewidth="118.0px" datasizeheight="80.0px" dataX="48.0" dataY="20.0"   alt="image" systemName="./images/bc875172-a90b-4b46-9486-22778db358db.svg" overlay="#CBCBCB">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="40px" version="1.1" viewBox="0 0 54 40" width="54px">\
              	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
              	    <title>Page 1 Copy 5</title>\
              	    <desc>Created with Sketch.</desc>\
              	    <defs />\
              	    <g fill="none" fill-rule="evenodd" id="s-Image_24-Page-1" stroke="none" stroke-width="1">\
              	        <g fill="#CBCBCB" id="s-Image_24-Components" transform="translate(-865.000000, -1458.000000)">\
              	            <g id="s-Image_24-Page-1-Copy-5" transform="translate(865.000000, 1458.000000)">\
              	                <path d="M2.74576271,37.2093023 L51.2542373,37.2093023 L51.2542373,2.79069767 L2.74576271,2.79069767 L2.74576271,37.2093023 Z M52.6271186,0 L1.37288136,0 C0.615966102,0 0,0.626046512 0,1.39534884 L0,38.6046512 C0,39.3739535 0.615966102,40 1.37288136,40 L52.6271186,40 C53.3840339,40 54,39.3739535 54,38.6046512 L54,1.39534884 C54,0.626046512 53.3840339,0 52.6271186,0 Z" id="s-Image_24-Fill-1" style="fill:#CBCBCB !important;" />\
              	                <path d="M14.9995483,9.471768 C16.3944349,9.471768 17.5291354,10.6055651 17.5291354,11.9995483 C17.5291354,13.3944349 16.3944349,14.528232 14.9995483,14.528232 C13.6055651,14.528232 12.4708646,13.3944349 12.4708646,12.0004517 C12.4708646,10.6055651 13.6055651,9.471768 14.9995483,9.471768 M14.9995483,17 C17.7577017,17 20,14.7577017 20,12.0004517 C20,9.24410516 17.7577017,7 14.9995483,7 C12.2422983,7 10,9.24320173 10,11.9995483 C10,14.7567983 12.2422983,17 14.9995483,17" id="s-Image_24-Fill-3" style="fill:#CBCBCB !important;" />\
              	                <path d="M6.40718098,36 C6.74842583,36 7.07842085,35.8780915 7.33529197,35.6571897 L22.2985036,22.7770565 L31.646175,31.9156082 C32.1946042,32.4509055 33.0861533,32.4499889 33.6345825,31.9156082 C34.1820742,31.3784777 34.1820742,30.5067863 33.6345825,29.971489 L29.4440207,25.8742647 L37.4332751,17.3214236 L47.6434335,26.4737244 C48.2152999,26.9861066 49.1068489,26.9466926 49.6309035,26.3884801 C49.8849622,26.117165 50.0162102,25.7651887 49.998398,25.3985467 C49.9815232,25.0309881 49.8202757,24.6927609 49.5437173,24.4461942 L38.2929497,14.3626227 C38.0238912,14.1224722 37.6845214,13.9794818 37.280465,14.0023969 C36.9054706,14.0198124 36.5586008,14.1783851 36.3054797,14.4497002 L27.4537383,23.9273957 L23.3541127,19.9181655 C22.8309956,19.4094498 21.9863208,19.381035 21.4313292,19.8595028 L5.4781325,33.5929953 C5.19594926,33.8358956 5.02626432,34.1713731 5.00282718,34.5370984 C4.97939003,34.904657 5.10220068,35.25755 5.35157191,35.5343647 C5.61875538,35.8295115 6.00312458,36 6.40718098,36" id="s-Image_24-Fill-4" style="fill:#CBCBCB !important;" />\
              	            </g>\
              	        </g>\
              	    </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Paragraph_2" class="pie richtext autofit firer ie-background commentable non-processed" customid="로고 이름"   datasizewidth="89.1px" datasizeheight="67.0px" dataX="194.0" dataY="25.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_2_0">AUS</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Paragraph_6" class="pie richtext autofit firer ie-background commentable non-processed" customid="About 메뉴"   datasizewidth="131.4px" datasizeheight="67.0px" dataX="1115.0" dataY="26.5" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_6_0">About</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_7" class="pie richtext autofit firer ie-background commentable non-processed" customid="시작하기 메뉴"   datasizewidth="186.7px" datasizeheight="67.0px" dataX="1296.0" dataY="26.5" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_7_0">시작하기</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_8" class="pie richtext autofit firer ie-background commentable non-processed" customid="마이페이지 메뉴"   datasizewidth="233.3px" datasizeheight="67.0px" dataX="1511.0" dataY="26.5" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_8_0">마이페이지</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Rectangle_2" class="pie rectangle manualfit firer commentable non-processed" customid="사이드바 배경"   datasizewidth="922.0px" datasizeheight="567.0px" datasizewidthpx="921.9999999999992" datasizeheightpx="566.9999999999995" dataX="499.0" dataY="292.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_5" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_4"   datasizewidth="160.0px" datasizeheight="43.0px" datasizewidthpx="160.0" datasizeheightpx="43.0" dataX="1261.0" dataY="873.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_5_0">종료</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_6" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_2"   datasizewidth="160.0px" datasizeheight="43.0px" datasizewidthpx="160.0" datasizeheightpx="43.0" dataX="1090.0" dataY="873.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_6_0">일시정지</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="225.3px" datasizeheight="30.0px" dataX="499.0" dataY="880.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">공부시간 &nbsp;00:00:00</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_7" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_4"   datasizewidth="160.0px" datasizeheight="43.0px" datasizewidthpx="160.0" datasizeheightpx="43.0" dataX="880.0" dataY="554.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_7_0">시작하기</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_4" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle 4"   datasizewidth="130.0px" datasizeheight="43.0px" datasizewidthpx="130.0" datasizeheightpx="43.0" dataX="935.0" dataY="874.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_4_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_3" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph 3"   datasizewidth="42.7px" datasizeheight="24.0px" dataX="954.0" dataY="883.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0">알림</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="shapewrapper-s-Ellipse_2" customid="Ellipse 2" class="shapewrapper shapewrapper-s-Ellipse_2 non-processed"   datasizewidth="29.0px" datasizeheight="27.9px" datasizewidthpx="29.0" datasizeheightpx="27.91250000000008" dataX="1028.0" dataY="881.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_2" class="svgContainer" style="width:100%; height:100%;">\
              <g>\
                  <g clip-path="url(#clip-s-Ellipse_2)">\
                          <ellipse id="s-Ellipse_2" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse 2" cx="14.5" cy="13.95625000000004" rx="14.5" ry="13.95625000000004">\
                          </ellipse>\
                  </g>\
              </g>\
              <defs>\
                  <clipPath id="clip-s-Ellipse_2" class="clipPath">\
                          <ellipse cx="14.5" cy="13.95625000000004" rx="14.5" ry="13.95625000000004">\
                          </ellipse>\
                  </clipPath>\
              </defs>\
          </svg>\
          <div class="paddingLayer">\
              <div id="shapert-s-Ellipse_2" class="content firer" >\
                  <div class="valign">\
                      <span id="rtr-s-Ellipse_2_0"></span>\
                  </div>\
              </div>\
          </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;