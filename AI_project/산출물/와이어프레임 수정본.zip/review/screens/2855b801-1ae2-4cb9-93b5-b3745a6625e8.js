var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1920" deviceHeight="1080">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1920" height="1080">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1615769010812.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1615769010812-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-2855b801-1ae2-4cb9-93b5-b3745a6625e8" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="카카오 로그인" width="1920" height="1080">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/2855b801-1ae2-4cb9-93b5-b3745a6625e8-1615769010812.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/2855b801-1ae2-4cb9-93b5-b3745a6625e8-1615769010812-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/2855b801-1ae2-4cb9-93b5-b3745a6625e8-1615769010812-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Rectangle_3" class="pie rectangle manualfit firer commentable non-processed" customid="전체 배경"   datasizewidth="1920.0px" datasizeheight="1080.0px" datasizewidthpx="1919.9999999999998" datasizeheightpx="1080.0" dataX="0.0" dataY="0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_3_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Card-5" class="group firer ie-background commentable non-processed" customid="Card-5" datasizewidth="405.0px" datasizeheight="490.0px" >\
        <div id="s-Rectangle_11" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_11"   datasizewidth="516.0px" datasizeheight="386.0px" datasizewidthpx="516.0000000000001" datasizeheightpx="385.99999999999983" dataX="702.0" dataY="399.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_11_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_12" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_12"   datasizewidth="516.0px" datasizeheight="254.0px" datasizewidthpx="516.0000000000001" datasizeheightpx="254.00000000000006" dataX="702.0" dataY="399.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_12_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Title_16" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Title_16"   datasizewidth="403.9px" datasizeheight="107.0px" dataX="758.0" dataY="471.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Title_16_0">제잘제잘(가제)을 카톡으로 간편 로그인하세요 </span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Title_17" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Title_17"   datasizewidth="123.6px" datasizeheight="18.0px" dataX="758.0" dataY="431.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Title_17_0">제잘제잘</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_38" class="pie image lockV firer ie-background commentable non-processed" customid="Image_38"   datasizewidth="22.9px" datasizeheight="28.0px" dataX="777.0" dataY="705.0" aspectRatio="1.2222222"   alt="image" systemName="./images/f048e0a0-b82a-40ff-beaf-f3e38e00e762.svg" overlay="#FFFFFF">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 17 20" width="17px">\
            	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
            	    <title>Page 1</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <defs>\
            	        <polygon id="s-Image_38-path-1" points="0 1.12646002e-05 16.9999924 1.12646002e-05 16.9999924 7.96031746 0 7.96031746" fill="#FFFFFF" jimofill=" " />\
            	    </defs>\
            	    <g fill="none" fill-rule="evenodd" id="s-Image_38-Page-1" stroke="none" stroke-width="1">\
            	        <g id="Header-#4" transform="translate(-1082.000000, -25.000000)">\
            	            <g id="s-Image_38-Page-1" transform="translate(1082.000000, 25.000000)">\
            	                <path d="M8.63492063,0 C5.80790159,0 3.50793651,2.29996508 3.50793651,5.12698413 C3.50793651,7.95400317 5.80790159,10.2539683 8.63492063,10.2539683 C11.4619397,10.2539683 13.7619048,7.95400317 13.7619048,5.12698413 C13.7619048,2.29996508 11.4619397,0 8.63492063,0" fill="#666666" id="s-Image_38-Fill-1" style="fill:#FFFFFF !important;" />\
            	                <g id="s-Image_38-Group-5" transform="translate(0.000000, 11.468254)">\
            	                    <mask fill="white" id="s-Image_38-mask-2">\
            	                        <use xlink:href="#s-Image_38-path-1" style="fill:#FFFFFF !important;" />\
            	                    </mask>\
            	                    <g id="s-Image_38-Clip-4" />\
            	                    <path d="M9.63332578,1.12646002e-05 L7.36665911,1.12646002e-05 C5.40191244,1.12646002e-05 3.55087689,0.776029571 2.15461022,2.18515596 C0.765181333,3.58737339 -7.55555556e-06,5.43829739 -7.55555556e-06,7.39709872 C-7.55555556e-06,7.70815188 0.253708,7.96032872 0.566659111,7.96032872 L16.4333258,7.96032872 C16.7462769,7.96032872 16.9999924,7.70815188 16.9999924,7.39709872 C16.9999924,5.43829739 16.2348036,3.58737339 14.8453747,2.18515596 C13.449108,0.776029571 11.5981102,1.12646002e-05 9.63332578,1.12646002e-05 Z" fill="#666666" id="s-Image_38-Fill-3" mask="url(#s-Image_38-mask-2)" style="fill:#FFFFFF !important;" />\
            	                </g>\
            	            </g>\
            	        </g>\
            	    </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Title_18" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Title_17"   datasizewidth="392.6px" datasizeheight="72.0px" dataX="758.0" dataY="556.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Title_18_0">간편 로그인 후에 제잘제잘의 모든 서비스를 이용할 수 있습니다</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_1" class="pie image firer click ie-background commentable non-processed" customid="Image 1"   datasizewidth="300.0px" datasizeheight="45.0px" dataX="810.0" dataY="695.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/2a2356d0-e038-4544-9a7a-92d00a36869c.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph 1"   datasizewidth="149.3px" datasizeheight="43.0px" dataX="55.0" dataY="9.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">제잘제잘</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="상단 바" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_1" class="pie rectangle manualfit firer commentable non-processed" customid="상단 바 배경"   datasizewidth="1920.0px" datasizeheight="120.0px" datasizewidthpx="1919.9999999999998" datasizeheightpx="120.0" dataX="0.0" dataY="0.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_6" class="group firer ie-background commentable non-processed" customid="로고" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Image_24" class="pie image firer ie-background commentable non-processed" customid="로고 이미지"   datasizewidth="118.0px" datasizeheight="80.0px" dataX="48.0" dataY="20.0"   alt="image" systemName="./images/8b66a2aa-4728-4f97-8210-a166811df5fd.svg" overlay="#CBCBCB">\
            <div class="borderLayer">\
            	<div class="imageViewport">\
              	<?xml version="1.0" encoding="UTF-8"?>\
              	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="40px" version="1.1" viewBox="0 0 54 40" width="54px">\
              	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
              	    <title>Page 1 Copy 5</title>\
              	    <desc>Created with Sketch.</desc>\
              	    <defs />\
              	    <g fill="none" fill-rule="evenodd" id="s-Image_24-Page-1" stroke="none" stroke-width="1">\
              	        <g fill="#CBCBCB" id="s-Image_24-Components" transform="translate(-865.000000, -1458.000000)">\
              	            <g id="s-Image_24-Page-1-Copy-5" transform="translate(865.000000, 1458.000000)">\
              	                <path d="M2.74576271,37.2093023 L51.2542373,37.2093023 L51.2542373,2.79069767 L2.74576271,2.79069767 L2.74576271,37.2093023 Z M52.6271186,0 L1.37288136,0 C0.615966102,0 0,0.626046512 0,1.39534884 L0,38.6046512 C0,39.3739535 0.615966102,40 1.37288136,40 L52.6271186,40 C53.3840339,40 54,39.3739535 54,38.6046512 L54,1.39534884 C54,0.626046512 53.3840339,0 52.6271186,0 Z" id="s-Image_24-Fill-1" style="fill:#CBCBCB !important;" />\
              	                <path d="M14.9995483,9.471768 C16.3944349,9.471768 17.5291354,10.6055651 17.5291354,11.9995483 C17.5291354,13.3944349 16.3944349,14.528232 14.9995483,14.528232 C13.6055651,14.528232 12.4708646,13.3944349 12.4708646,12.0004517 C12.4708646,10.6055651 13.6055651,9.471768 14.9995483,9.471768 M14.9995483,17 C17.7577017,17 20,14.7577017 20,12.0004517 C20,9.24410516 17.7577017,7 14.9995483,7 C12.2422983,7 10,9.24320173 10,11.9995483 C10,14.7567983 12.2422983,17 14.9995483,17" id="s-Image_24-Fill-3" style="fill:#CBCBCB !important;" />\
              	                <path d="M6.40718098,36 C6.74842583,36 7.07842085,35.8780915 7.33529197,35.6571897 L22.2985036,22.7770565 L31.646175,31.9156082 C32.1946042,32.4509055 33.0861533,32.4499889 33.6345825,31.9156082 C34.1820742,31.3784777 34.1820742,30.5067863 33.6345825,29.971489 L29.4440207,25.8742647 L37.4332751,17.3214236 L47.6434335,26.4737244 C48.2152999,26.9861066 49.1068489,26.9466926 49.6309035,26.3884801 C49.8849622,26.117165 50.0162102,25.7651887 49.998398,25.3985467 C49.9815232,25.0309881 49.8202757,24.6927609 49.5437173,24.4461942 L38.2929497,14.3626227 C38.0238912,14.1224722 37.6845214,13.9794818 37.280465,14.0023969 C36.9054706,14.0198124 36.5586008,14.1783851 36.3054797,14.4497002 L27.4537383,23.9273957 L23.3541127,19.9181655 C22.8309956,19.4094498 21.9863208,19.381035 21.4313292,19.8595028 L5.4781325,33.5929953 C5.19594926,33.8358956 5.02626432,34.1713731 5.00282718,34.5370984 C4.97939003,34.904657 5.10220068,35.25755 5.35157191,35.5343647 C5.61875538,35.8295115 6.00312458,36 6.40718098,36" id="s-Image_24-Fill-4" style="fill:#CBCBCB !important;" />\
              	            </g>\
              	        </g>\
              	    </g>\
              	</svg>\
\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Paragraph_2" class="pie richtext autofit firer ie-background commentable non-processed" customid="로고 이름"   datasizewidth="89.1px" datasizeheight="67.0px" dataX="194.0" dataY="25.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_2_0">AUS</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Paragraph_6" class="pie richtext autofit firer ie-background commentable non-processed" customid="About 메뉴"   datasizewidth="131.4px" datasizeheight="67.0px" dataX="1743.0" dataY="26.5" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_6_0">About</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;