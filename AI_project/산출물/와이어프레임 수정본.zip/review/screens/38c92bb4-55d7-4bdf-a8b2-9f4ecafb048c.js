var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1920" deviceHeight="1080">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1920" height="1080">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1615769010812.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1615769010812-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-38c92bb4-55d7-4bdf-a8b2-9f4ecafb048c" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="마이페이지_분석_그룹" width="1920" height="1080">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/38c92bb4-55d7-4bdf-a8b2-9f4ecafb048c-1615769010812.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/38c92bb4-55d7-4bdf-a8b2-9f4ecafb048c-1615769010812-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/38c92bb4-55d7-4bdf-a8b2-9f4ecafb048c-1615769010812-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="마이페이지 양식" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_3" class="pie rectangle manualfit firer commentable non-processed" customid="전체 배경"   datasizewidth="1920.0px" datasizeheight="1080.0px" datasizewidthpx="1919.9999999999998" datasizeheightpx="1080.0" dataX="0.0" dataY="-1.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_3_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_2" class="pie rectangle manualfit firer commentable non-processed" customid="사이드바 배경"   datasizewidth="337.0px" datasizeheight="960.0px" datasizewidthpx="336.9999999999999" datasizeheightpx="960.0" dataX="0.0" dataY="121.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_2_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_10" class="pie richtext autofit firer ie-background commentable non-processed" customid="큰 제목"   datasizewidth="152.1px" datasizeheight="67.0px" dataX="397.0" dataY="153.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_10_0">큰 제목</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_3" class="group firer ie-background commentable non-processed" customid="분석" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Rectangle_5" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="272.0px" datasizeheight="81.0px" datasizewidthpx="272.0" datasizeheightpx="81.0" dataX="32.0" dataY="358.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_5_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="shapewrapper-s-Circle_1" customid="Circle" class="shapewrapper shapewrapper-s-Circle_1 non-processed"   datasizewidth="52.0px" datasizeheight="52.0px" datasizewidthpx="52.0" datasizeheightpx="52.0" dataX="48.0" dataY="373.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Circle_1" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Circle_1)">\
                              <ellipse id="s-Circle_1" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Circle" cx="26.0" cy="26.0" rx="26.0" ry="26.0">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Circle_1" class="clipPath">\
                              <ellipse cx="26.0" cy="26.0" rx="26.0" ry="26.0">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Circle_1" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Circle_1_0"></span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
          <div id="s-Paragraph_4" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph_3"   datasizewidth="69.3px" datasizeheight="49.0px" dataX="125.0" dataY="376.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_4_0">분석</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_4" class="group firer ie-background commentable non-processed" customid="회원정보" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Rectangle_6" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="272.0px" datasizeheight="81.0px" datasizewidthpx="272.0" datasizeheightpx="81.0" dataX="32.0" dataY="539.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_6_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="shapewrapper-s-Circle_2" customid="Circle" class="shapewrapper shapewrapper-s-Circle_2 non-processed"   datasizewidth="52.0px" datasizeheight="52.0px" datasizewidthpx="52.0" datasizeheightpx="52.0" dataX="48.0" dataY="554.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Circle_2" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Circle_2)">\
                              <ellipse id="s-Circle_2" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Circle" cx="26.0" cy="26.0" rx="26.0" ry="26.0">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Circle_2" class="clipPath">\
                              <ellipse cx="26.0" cy="26.0" rx="26.0" ry="26.0">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Circle_2" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Circle_2_0"></span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
          <div id="s-Paragraph_5" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph_3"   datasizewidth="138.7px" datasizeheight="49.0px" dataX="125.0" dataY="557.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_5_0">타임라인</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_5" class="group firer ie-background commentable non-processed" customid="상단 바" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Rectangle_4" class="pie rectangle manualfit firer commentable non-processed" customid="상단 바 배경"   datasizewidth="1920.0px" datasizeheight="120.0px" datasizewidthpx="1919.9999999999998" datasizeheightpx="120.0" dataX="0.0" dataY="1.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_4_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Group_6" class="group firer ie-background commentable non-processed" customid="회원 아이콘" datasizewidth="60.0px" datasizeheight="60.0px" >\
            <div id="shapewrapper-s-Ellipse_1" customid="Ellipse_1" class="shapewrapper shapewrapper-s-Ellipse_1 non-processed"   datasizewidth="89.0px" datasizeheight="89.0px" datasizewidthpx="89.0" datasizeheightpx="89.0" dataX="1804.0" dataY="17.0" >\
                <div class="backgroundLayer">\
                  <div class="colorLayer"></div>\
                  <div class="imageLayer"></div>\
                </div>\
                <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Ellipse_1" class="svgContainer" style="width:100%; height:100%;">\
                    <g>\
                        <g clip-path="url(#clip-s-Ellipse_1)">\
                                <ellipse id="s-Ellipse_1" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Ellipse_1" cx="44.5" cy="44.5" rx="44.5" ry="44.5">\
                                </ellipse>\
                        </g>\
                    </g>\
                    <defs>\
                        <clipPath id="clip-s-Ellipse_1" class="clipPath">\
                                <ellipse cx="44.5" cy="44.5" rx="44.5" ry="44.5">\
                                </ellipse>\
                        </clipPath>\
                    </defs>\
                </svg>\
                <div class="paddingLayer">\
                    <div id="shapert-s-Ellipse_1" class="content firer" >\
                        <div class="valign">\
                            <span id="rtr-s-Ellipse_1_0"></span>\
                        </div>\
                    </div>\
                </div>\
            </div>\
\
            <div id="s-Image_35" class="pie image firer ie-background commentable non-processed" customid="Image_35"   datasizewidth="44.5px" datasizeheight="51.9px" dataX="1826.0" dataY="34.0"   alt="image" systemName="./images/27650849-ce6b-42a9-b384-ba4655ccca36.svg" overlay="#999999">\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 17 20" width="17px">\
                	    <!-- Generator: Sketch 52.1 (67048) - http://www.bohemiancoding.com/sketch -->\
                	    <title>user</title>\
                	    <desc>Created with Sketch.</desc>\
                	    <g fill="none" fill-rule="evenodd" id="s-Image_35-Page-1" stroke="none" stroke-width="1">\
                	        <g fill="#666666" id="s-Image_35-user">\
                	            <path d="M8.63492063,0 C5.80790159,0 3.50793651,2.29996508 3.50793651,5.12698413 C3.50793651,7.95400317 5.80790159,10.2539683 8.63492063,10.2539683 C11.4619397,10.2539683 13.7619048,7.95400317 13.7619048,5.12698413 C13.7619048,2.29996508 11.4619397,0 8.63492063,0" id="s-Image_35-Fill-1" style="fill:#999999 !important;" />\
                	            <path d="M9.63332578,11.4682653 L7.36665911,11.4682653 C5.40191244,11.4682653 3.55087689,12.2442836 2.15461022,13.65341 C0.765181333,15.0556274 -7.55555556e-06,16.9065514 -7.55555556e-06,18.8653527 C-7.55555556e-06,19.1764059 0.253708,19.4285827 0.566659111,19.4285827 L16.4333258,19.4285827 C16.7462769,19.4285827 16.9999924,19.1764059 16.9999924,18.8653527 C16.9999924,16.9065514 16.2348036,15.0556274 14.8453747,13.65341 C13.449108,12.2442836 11.5981102,11.4682653 9.63332578,11.4682653 Z" id="s-Image_35-Fill-3" style="fill:#999999 !important;" />\
                	        </g>\
                	    </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
\
          </div>\
\
\
          <div id="s-Group_7" class="group firer ie-background commentable non-processed" customid="로고" datasizewidth="0.0px" datasizeheight="0.0px" >\
            <div id="s-Image_24" class="pie image firer ie-background commentable non-processed" customid="로고 이미지"   datasizewidth="118.0px" datasizeheight="80.0px" dataX="48.0" dataY="21.0"   alt="image" systemName="./images/5c104359-85d8-4545-891a-ab7ad4d1a9b8.svg" overlay="#CBCBCB">\
              <div class="borderLayer">\
              	<div class="imageViewport">\
                	<?xml version="1.0" encoding="UTF-8"?>\
                	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="40px" version="1.1" viewBox="0 0 54 40" width="54px">\
                	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
                	    <title>Page 1 Copy 5</title>\
                	    <desc>Created with Sketch.</desc>\
                	    <defs />\
                	    <g fill="none" fill-rule="evenodd" id="s-Image_24-Page-1" stroke="none" stroke-width="1">\
                	        <g fill="#CBCBCB" id="s-Image_24-Components" transform="translate(-865.000000, -1458.000000)">\
                	            <g id="s-Image_24-Page-1-Copy-5" transform="translate(865.000000, 1458.000000)">\
                	                <path d="M2.74576271,37.2093023 L51.2542373,37.2093023 L51.2542373,2.79069767 L2.74576271,2.79069767 L2.74576271,37.2093023 Z M52.6271186,0 L1.37288136,0 C0.615966102,0 0,0.626046512 0,1.39534884 L0,38.6046512 C0,39.3739535 0.615966102,40 1.37288136,40 L52.6271186,40 C53.3840339,40 54,39.3739535 54,38.6046512 L54,1.39534884 C54,0.626046512 53.3840339,0 52.6271186,0 Z" id="s-Image_24-Fill-1" style="fill:#CBCBCB !important;" />\
                	                <path d="M14.9995483,9.471768 C16.3944349,9.471768 17.5291354,10.6055651 17.5291354,11.9995483 C17.5291354,13.3944349 16.3944349,14.528232 14.9995483,14.528232 C13.6055651,14.528232 12.4708646,13.3944349 12.4708646,12.0004517 C12.4708646,10.6055651 13.6055651,9.471768 14.9995483,9.471768 M14.9995483,17 C17.7577017,17 20,14.7577017 20,12.0004517 C20,9.24410516 17.7577017,7 14.9995483,7 C12.2422983,7 10,9.24320173 10,11.9995483 C10,14.7567983 12.2422983,17 14.9995483,17" id="s-Image_24-Fill-3" style="fill:#CBCBCB !important;" />\
                	                <path d="M6.40718098,36 C6.74842583,36 7.07842085,35.8780915 7.33529197,35.6571897 L22.2985036,22.7770565 L31.646175,31.9156082 C32.1946042,32.4509055 33.0861533,32.4499889 33.6345825,31.9156082 C34.1820742,31.3784777 34.1820742,30.5067863 33.6345825,29.971489 L29.4440207,25.8742647 L37.4332751,17.3214236 L47.6434335,26.4737244 C48.2152999,26.9861066 49.1068489,26.9466926 49.6309035,26.3884801 C49.8849622,26.117165 50.0162102,25.7651887 49.998398,25.3985467 C49.9815232,25.0309881 49.8202757,24.6927609 49.5437173,24.4461942 L38.2929497,14.3626227 C38.0238912,14.1224722 37.6845214,13.9794818 37.280465,14.0023969 C36.9054706,14.0198124 36.5586008,14.1783851 36.3054797,14.4497002 L27.4537383,23.9273957 L23.3541127,19.9181655 C22.8309956,19.4094498 21.9863208,19.381035 21.4313292,19.8595028 L5.4781325,33.5929953 C5.19594926,33.8358956 5.02626432,34.1713731 5.00282718,34.5370984 C4.97939003,34.904657 5.10220068,35.25755 5.35157191,35.5343647 C5.61875538,35.8295115 6.00312458,36 6.40718098,36" id="s-Image_24-Fill-4" style="fill:#CBCBCB !important;" />\
                	            </g>\
                	        </g>\
                	    </g>\
                	</svg>\
\
                </div>\
              </div>\
            </div>\
\
            <div id="s-Paragraph_2" class="pie richtext autofit firer ie-background commentable non-processed" customid="로고 이름"   datasizewidth="89.1px" datasizeheight="67.0px" dataX="194.0" dataY="26.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <div class="borderLayer">\
                <div class="paddingLayer">\
                  <div class="content">\
                    <div class="valign">\
                      <span id="rtr-s-Paragraph_2_0">AUS</span>\
                    </div>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
\
          <div id="s-Paragraph_6" class="pie richtext autofit firer ie-background commentable non-processed" customid="About 메뉴"   datasizewidth="131.4px" datasizeheight="67.0px" dataX="1115.0" dataY="28.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_6_0">About</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_7" class="pie richtext autofit firer ie-background commentable non-processed" customid="시작하기 메뉴"   datasizewidth="186.7px" datasizeheight="67.0px" dataX="1296.0" dataY="28.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_7_0">시작하기</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_8" class="pie richtext autofit firer ie-background commentable non-processed" customid="마이페이지 메뉴"   datasizewidth="233.3px" datasizeheight="67.0px" dataX="1511.0" dataY="28.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_8_0">마이페이지</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_8" class="group firer ie-background commentable non-processed" customid="그룹관리" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Rectangle_7" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle"   datasizewidth="272.0px" datasizeheight="81.0px" datasizewidthpx="272.0" datasizeheightpx="81.0" dataX="32.0" dataY="724.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_7_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="shapewrapper-s-Circle_3" customid="Circle" class="shapewrapper shapewrapper-s-Circle_3 non-processed"   datasizewidth="52.0px" datasizeheight="52.0px" datasizewidthpx="52.0" datasizeheightpx="52.0" dataX="48.0" dataY="739.0" >\
              <div class="backgroundLayer">\
                <div class="colorLayer"></div>\
                <div class="imageLayer"></div>\
              </div>\
              <svg version="1.1" baseProfile="full" xmlns="http://www.w3.org/2000/svg" id="svg-s-Circle_3" class="svgContainer" style="width:100%; height:100%;">\
                  <g>\
                      <g clip-path="url(#clip-s-Circle_3)">\
                              <ellipse id="s-Circle_3" class="pie ellipse shape non-processed-shape manualfit firer commentable non-processed" customid="Circle" cx="26.0" cy="26.0" rx="26.0" ry="26.0">\
                              </ellipse>\
                      </g>\
                  </g>\
                  <defs>\
                      <clipPath id="clip-s-Circle_3" class="clipPath">\
                              <ellipse cx="26.0" cy="26.0" rx="26.0" ry="26.0">\
                              </ellipse>\
                      </clipPath>\
                  </defs>\
              </svg>\
              <div class="paddingLayer">\
                  <div id="shapert-s-Circle_3" class="content firer" >\
                      <div class="valign">\
                          <span id="rtr-s-Circle_3_0"></span>\
                      </div>\
                  </div>\
              </div>\
          </div>\
          <div id="s-Paragraph_9" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph_3"   datasizewidth="138.7px" datasizeheight="49.0px" dataX="125.0" dataY="742.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_9_0">그룹관리</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
      </div>\
\
\
      <div id="s-Group_10" class="group firer ie-background commentable non-processed" customid="분석 탭" datasizewidth="517.0px" datasizeheight="41.0px" >\
        <div id="s-Rectangle_14" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_1"   datasizewidth="201.5px" datasizeheight="75.0px" datasizewidthpx="201.52321883257468" datasizeheightpx="75.0" dataX="644.1" dataY="256.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_14_0">그룹</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Rectangle_17" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_4"   datasizewidth="201.5px" datasizeheight="75.0px" datasizewidthpx="201.52321883257446" datasizeheightpx="75.0" dataX="446.0" dataY="256.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_17_0">내 활동</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Group_17" class="group firer ie-background commentable non-processed" customid="그룹 활동" datasizewidth="0.0px" datasizeheight="0.0px" >\
        <div id="s-Rectangle_13" class="pie rectangle manualfit firer commentable non-processed" customid="그룹 활동 배경"   datasizewidth="1586.0px" datasizeheight="720.0px" datasizewidthpx="1586.0" datasizeheightpx="720.0000000000001" dataX="334.0" dataY="361.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_13_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_13" class="pie richtext autofit firer ie-background commentable non-processed" customid="부제목"   datasizewidth="998.8px" datasizeheight="49.0px" dataX="627.6" dataY="481.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_13_0">2021.03.08 ~ 2021.03.14 &nbsp; SSAFY 특화 B102팀 &nbsp; 분석 결과입니다</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Group_13" class="group firer ie-background commentable non-processed" customid="평균 활동시간 데이터" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Rectangle_18" class="pie rectangle manualfit firer commentable non-processed" customid="개요 범위"   datasizewidth="462.0px" datasizeheight="202.0px" datasizewidthpx="462.0" datasizeheightpx="202.0" dataX="1361.0" dataY="555.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_18_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_16" class="pie richtext autofit firer ie-background commentable non-processed" customid="개요 제목"   datasizewidth="295.3px" datasizeheight="49.0px" dataX="1403.8" dataY="590.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_16_0">그룹 대비 학습시간</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_17" class="pie richtext autofit firer ie-background commentable non-processed" customid="개요 내용"   datasizewidth="93.3px" datasizeheight="67.0px" dataX="1403.8" dataY="656.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_17_0">낮음</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Group_16" class="group firer ie-background commentable non-processed" customid="평균 집중도 데이터" datasizewidth="0.0px" datasizeheight="0.0px" >\
          <div id="s-Rectangle_21" class="pie rectangle manualfit firer commentable non-processed" customid="개요 범위"   datasizewidth="462.0px" datasizeheight="202.0px" datasizewidthpx="462.0" datasizeheightpx="202.0" dataX="1361.0" dataY="813.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_21_0"></span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_22" class="pie richtext autofit firer ie-background commentable non-processed" customid="개요 제목"   datasizewidth="260.7px" datasizeheight="49.0px" dataX="1403.8" dataY="848.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_22_0">그룹 대비 집중도</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Paragraph_23" class="pie richtext autofit firer ie-background commentable non-processed" customid="개요 내용"   datasizewidth="93.3px" datasizeheight="67.0px" dataX="1403.8" dataY="914.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Paragraph_23_0">낮음</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Rectangle_1" class="pie rectangle manualfit firer commentable non-processed" customid="차트 배경"   datasizewidth="845.8px" datasizeheight="469.0px" datasizewidthpx="845.8359451293948" datasizeheightpx="469.0" dataX="446.0" dataY="557.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="차트 이미지"   datasizewidth="761.3px" datasizeheight="456.0px" dataX="488.3" dataY="563.5"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/9730af47-0ebf-45ed-acc8-2f098fb7f051.png" />\
          	</div>\
          </div>\
        </div>\
\
      </div>\
\
\
      <div id="s-Dropdown" class="group firer ie-background commentable non-processed" customid="기간 단위 드롭다운" datasizewidth="345.0px" datasizeheight="226.0px" >\
        <div id="s-Options" class="group firer ie-background commentable hidden non-processed" customid="Options" datasizewidth="345.0px" datasizeheight="181.0px" >\
          <div id="s-Rectangle_22" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_2"   datasizewidth="435.0px" datasizeheight="85.0px" datasizewidthpx="435.0" datasizeheightpx="85.0" dataX="1340.0" dataY="334.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_22_0">주 단위</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Rectangle_23" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_3"   datasizewidth="435.0px" datasizeheight="85.0px" datasizewidthpx="435.0" datasizeheightpx="85.0" dataX="1340.0" dataY="412.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_23_0">월 단위</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Rectangle_24" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_4"   datasizewidth="435.0px" datasizeheight="85.0px" datasizewidthpx="435.0" datasizeheightpx="85.0" dataX="1340.0" dataY="490.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_24_0">년 단위</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Rectangle_25" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_5"   datasizewidth="435.0px" datasizeheight="85.0px" datasizewidthpx="435.0" datasizeheightpx="85.0" dataX="1340.0" dataY="567.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_25_0">전체</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Input_1" class="pie text firer click commentable non-processed" customid="Input_1"  datasizewidth="435.0px" datasizeheight="79.6px" dataX="1340.0" dataY="256.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100" readonly="readonly" tabindex="-1" placeholder="주 단위"/></div></div>  </div></div></div>\
\
        <div id="s-arrow" class="pie image firer click ie-background commentable non-processed" customid="arrow"   datasizewidth="19.0px" datasizeheight="10.0px" dataX="1726.0" dataY="287.0"   alt="image" systemName="./images/ae973d34-661a-4941-ac94-1d1673e6ff81.svg" overlay="#CBCBCB">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="13px" version="1.1" viewBox="0 0 23 13" width="23px">\
            	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
            	    <title>Arrow Left</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <defs />\
            	    <g fill="none" fill-rule="evenodd" id="s-arrow-Page-1" stroke="none" stroke-width="1">\
            	        <g fill="#CBCBCB" id="s-arrow-Components" transform="translate(-658.000000, -518.000000)">\
            	            <g id="s-arrow-Inputs" transform="translate(100.000000, 498.000000)">\
            	                <g id="s-arrow-Arrow-Left" transform="translate(569.500000, 26.000000) rotate(270.000000) translate(-569.500000, -26.000000) translate(562.500000, 14.500000)">\
            	                    <polyline points="1.7525625 0 0.8125 0.939714286 10.8265625 11.1878571 0.8125 21.1033214 1.8890625 22.1785714 13 11.2461786 1.7525625 0" transform="translate(6.906250, 11.089286) scale(-1, 1) translate(-6.906250, -11.089286) " style="fill:#CBCBCB !important;" />\
            	                </g>\
            	            </g>\
            	        </g>\
            	    </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
      </div>\
\
\
      <div id="s-Dropdown_1" class="group firer ie-background commentable non-processed" customid="그룹 드롭다운" datasizewidth="345.0px" datasizeheight="226.0px" >\
        <div id="s-Options_1" class="group firer ie-background commentable hidden non-processed" customid="Options" datasizewidth="345.0px" datasizeheight="181.0px" >\
          <div id="s-Rectangle_26" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_2"   datasizewidth="435.0px" datasizeheight="85.0px" datasizewidthpx="435.0" datasizeheightpx="85.0" dataX="1340.0" dataY="468.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_26_0">전체</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
          <div id="s-Rectangle_27" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_3"   datasizewidth="435.0px" datasizeheight="85.0px" datasizewidthpx="435.0" datasizeheightpx="85.0" dataX="1340.0" dataY="546.0" >\
            <div class="backgroundLayer">\
              <div class="colorLayer"></div>\
              <div class="imageLayer"></div>\
            </div>\
            <div class="borderLayer">\
              <div class="paddingLayer">\
                <div class="content">\
                  <div class="valign">\
                    <span id="rtr-s-Rectangle_27_0">SSAFY 특화 B102팀</span>\
                  </div>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Input_2" class="pie text firer click commentable non-processed" customid="Input_1"  datasizewidth="435.0px" datasizeheight="79.6px" dataX="1340.0" dataY="390.0" ><div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100" readonly="readonly" tabindex="-1" placeholder="SSAFY 특화 B102팀"/></div></div>  </div></div></div>\
\
        <div id="s-arrow_1" class="pie image firer click ie-background commentable non-processed" customid="arrow"   datasizewidth="19.0px" datasizeheight="10.0px" dataX="1726.0" dataY="421.0"   alt="image" systemName="./images/28ed2f4a-6d91-4fe5-8e9c-e12cd101996f.svg" overlay="#CBCBCB">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="13px" version="1.1" viewBox="0 0 23 13" width="23px">\
            	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
            	    <title>Arrow Left</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <defs />\
            	    <g fill="none" fill-rule="evenodd" id="s-arrow_1-Page-1" stroke="none" stroke-width="1">\
            	        <g fill="#CBCBCB" id="s-arrow_1-Components" transform="translate(-658.000000, -518.000000)">\
            	            <g id="s-arrow_1-Inputs" transform="translate(100.000000, 498.000000)">\
            	                <g id="s-arrow_1-Arrow-Left" transform="translate(569.500000, 26.000000) rotate(270.000000) translate(-569.500000, -26.000000) translate(562.500000, 14.500000)">\
            	                    <polyline points="1.7525625 0 0.8125 0.939714286 10.8265625 11.1878571 0.8125 21.1033214 1.8890625 22.1785714 13 11.2461786 1.7525625 0" transform="translate(6.906250, 11.089286) scale(-1, 1) translate(-6.906250, -11.089286) " style="fill:#CBCBCB !important;" />\
            	                </g>\
            	            </g>\
            	        </g>\
            	    </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
      </div>\
\
      <div id="s-Paragraph_24" class="pie richtext autofit firer ie-background commentable non-processed" customid="그룹 선택 라벨"   datasizewidth="147.7px" datasizeheight="49.0px" dataX="1155.0" dataY="403.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_24_0">그룹 선택</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;